
PPStrings = {
	PP_CHAR_MALE = "Homme",  -- 'Male'
	PP_CHAR_FEMALE = "Femme", -- 'Female'
	PP_SORTAZ = "A à Z", -- 'A to Z'
	PP_SORTZA = "Z à A", -- 'Z to A'
	PP_SORTDC = "Prédéfinis puis Personnalisés", -- 'Default to Custom'
	PP_SORTCD = "Personnalisés puis Prédéfinis", -- 'Custom to Default'
	PP_TOTAL = "NOMBRE DE PORTRAITS", -- 'TOTAL PORTRAITS'
	PP_DEFAULT = "Prédéfinis: ", -- 'Default: '
	PP_CUSTOM = "Personnalisés: ", -- 'Custom: '
	PP_SORT = "Tri: ", -- 'Sort: '
	PP_SORT_LABEL = "TRI", -- 'SORT'
	PP_FILENAME = "Nom de fichier: " -- 'Filename'
}
