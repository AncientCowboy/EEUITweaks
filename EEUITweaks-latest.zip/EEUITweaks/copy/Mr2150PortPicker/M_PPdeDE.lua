PPStrings = {
	PP_CHAR_MALE = "Männlich",  -- 'Male'
	PP_CHAR_FEMALE = "Weiblich", -- 'Female'
	PP_SORTAZ = "A bis Z", -- 'A to Z'
	PP_SORTZA = "Z bis A", -- 'Z to A'
	PP_SORTDC = "Vorgefertigte, dann Eigene", -- 'Default to Custom'
	PP_SORTCD = "Eigene, dann Vorgefertigte", -- 'Custom to Default'
	PP_TOTAL = "Gesamte Porträts", -- 'TOTAL PORTRAITS'
	PP_DEFAULT = "Eigene: ", -- 'Default: '
	PP_CUSTOM = "Vorgefertigte: ", -- 'Custom: '
	PP_SORT = "Sortieren: ", -- 'Sort: '
	PP_SORT_LABEL = "SORTIEREN", -- 'SORT'
	PP_FILENAME = "Dateiname: " -- 'Filename'
}
