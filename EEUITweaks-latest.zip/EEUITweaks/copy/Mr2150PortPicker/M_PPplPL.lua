PPStrings = {
	PP_CHAR_MALE = "Mężczyzna",  -- 'Male'
	PP_CHAR_FEMALE = "Kobieta", -- 'Female'
	PP_SORTAZ = "od A do Z", -- 'A to Z'
	PP_SORTZA = "od Z do A", -- 'Z to A'
	PP_SORTDC = "Domyślne potem Własne", -- 'Default to Custom'
	PP_SORTCD = "Własne potem Domyśln", -- 'Custom to Default'
	PP_TOTAL = "Ilość portretów", -- 'TOTAL PORTRAITS'
	PP_DEFAULT = "Domyślne: ", -- 'Default: '
	PP_CUSTOM = "Własne: ", -- 'Custom: '
	PP_SORT = "Sortuj: ", -- 'Sort: '
	PP_SORT_LABEL = "Sortuj", -- 'SORT'
	PP_FILENAME = "Nazwa pliku: " -- 'Filename'
}
