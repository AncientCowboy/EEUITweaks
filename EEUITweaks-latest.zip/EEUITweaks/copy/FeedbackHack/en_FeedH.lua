local feedbackHackStrings 
feedbackHackStrings = {
	FEEDBACK_HACK_EXPAND_TT = "Expand Messages",
	FEEDBACK_HACK_SHRINK_TT = "Shrink Messages",
}

for k,v in pairs(feedbackHackStrings) do
	uiStrings[k]=v
end
