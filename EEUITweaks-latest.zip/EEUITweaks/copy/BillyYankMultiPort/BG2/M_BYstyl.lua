styles.label_port =
	{
		color = 'B',
		font = 'STONESML',
		point = 10,
		valign = 'center',
		halign = 'center',
    useFontZoom = 0,
	}
