if ((modOptionsStartMenu ~= nil) and (modOptionsStartupEnabled())) then
OptionsButtons = 
{
	{text = "CREDITS_BUTTON", menu = "CREDITS", sequence = 0}, 
	{text = "GAMEPLAY_BUTTON", menu = "OPTIONS_GAMEPLAY", sequence = 0}, 
	{text = "GRAPHICS_BUTTON", menu = "OPTIONS_GRAPHICS", sequence = 1}, 
	{text = "LANGUAGE_BUTTON", menu = "OPTIONS_LANGUAGE", sequence = 0}, 
	{text = "MODOPT_BUTTON", menu = "OPTIONS_MODS", sequence = 0}, 
	{text = "MOVIES_BUTTON", menu = "", sequence = 2}, 
	{text = "SOUND_BUTTON", menu = "OPTIONS_SOUND", sequence = 1}, 
}
end
