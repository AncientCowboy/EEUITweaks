`
if(modOptionsRegisterMenu) then
	modOptionsRegisterMenu('MODOPT_UISETTINGS_TITLE', 'UI_SETTINGS', 'MODOPT_UISETTINGS_INFO', 0)
end

`
